---
title: "Rscience - Anova - script03 - Anova - Model"
format: 
  html:
#    css: custom_theme.css
    grid:
      body-width: 2000px
      margin-width: 250px
      gutter-width: 1.5rem
    toc: true
    toc-float: true
    toc-location: right
    self-contained: true
    link-citations: true # Util para ver referencias en el margen (ver `tufte.html` en la galería de Quarto)
knitr: 
    opts_chunk: 
        collapse: false
        comment: ""
---


```{r}
#| eval: true
#| echo: true
#| message: false
#| warning: false
library(dplyr)
library(plotly)
```

```{r eval=TRUE, echo=FALSE, message=FALSE, warning=FALSE}
# Libraries
  library("htmlwidgets")
  library("knitr")


# General config
options(width = 500)

```

```{r eval=TRUE, echo=FALSE}
folder_fn_local_relative <- "../zzz_fn_local"
folder_fn_local_absolute <- normalizePath(folder_fn_local_relative, mustWork = T)
vector_fn <- list.files(
  path = folder_fn_local_absolute, 
  pattern = "^fn_local.*\\.R$", 
  full.names = TRUE
)
vector_fn <- normalizePath(vector_fn, mustWork = T)

invisible(lapply(vector_fn, source, local = FALSE, encoding = "UTF-8"))
#lapply(vector_fn, source, local = FALSE, encoding = "UTF-8")
``` 


```{r eval=TRUE, echo=TRUE} 
# load("R_obj_env_script01_anova_import_and_control.RData")
# vector_all_obj_init <- ls(envir = .GlobalEnv)

# 1. Definir la ruta del archivo
path_rdata_file01 <- "R_obj_env_file01_anova_import_and_control.RData"
path_rdata_file02 <- "R_obj_env_file02_anova_full_test.RData"


# 4. Convertir el entorno a una lista
list_obj_file01 <- fn_load_env_RData_hidden(path_rdata = path_rdata_file01)
list_obj_file02 <- fn_load_env_RData_hidden(path_rdata = path_rdata_file02)



```

```{r eval=TRUE, echo=TRUE} 
# From Script01
var_name_rv <- list_obj_file01$var_name_rv
var_name_factor <- list_obj_file01$var_name_factor
my_minidataset <-  list_obj_file01$my_minidataset 
df_factor_info <- list_obj_file01$df_factor_info
vector_color_levels_new <- list_obj_file01$vector_color_levels_new
alpha_value <- list_obj_file01$alpha_value
my_minidataset <- list_obj_file01$my_minidataset
vector_order_levels_new <- list_obj_file01$vector_order_levels_new

# From Script02
my_minidataset_ext <- list_obj_file02$my_minidataset_ext
df_model_error <- list_obj_file02$df_model_error
df_tukey_table_classroom <- list_obj_file02$df_tukey_table_classroom
model_error_var_MSE <- list_obj_file02$model_error_var_MSE
model_error_sd <- list_obj_file02$model_error_sd
```

```{r eval=TRUE, echo=TRUE} 

rm(list_obj_file01)
rm(list_obj_file02)
vector_all_obj_init <- ls(envir = .GlobalEnv)
#vector_all_obj_init <- ""
```



# Medidas de posición de los residuos para cada nivel del factor.
```{r eval=TRUE, echo=TRUE}   

  # # # # # Section 11 - Partitioned Measures (Residuals)-------------------------
  # # # Partitioned Measures of Position (residuals)
  df_residuals_position_levels <- data.frame(
    "order_level"  = 1:nlevels(my_minidataset_ext[,var_name_factor]),
    "level" = levels(my_minidataset_ext[,var_name_factor]),
    "n"            = tapply(my_minidataset_ext[,var_name_rv], my_minidataset_ext[,var_name_factor], length),
    "variable"     = rep("residuals", nlevels(my_minidataset_ext[,var_name_factor])),
    "min"          = tapply(my_minidataset_ext$"residuals", my_minidataset_ext[,var_name_factor], min),
    "mean"         = tapply(my_minidataset_ext$"residuals", my_minidataset_ext[,var_name_factor], mean),
    "Q1"           = tapply(my_minidataset_ext$"residuals", my_minidataset_ext[,var_name_factor], quantile, 0.25),
    "median"       = tapply(my_minidataset_ext$"residuals", my_minidataset_ext[,var_name_factor], median),
    "Q3"           = tapply(my_minidataset_ext$"residuals", my_minidataset_ext[,var_name_factor], quantile, 0.75),
    "max"          = tapply(my_minidataset_ext$"residuals", my_minidataset_ext[,var_name_factor], max),
    stringsAsFactors = FALSE
  )
    df_residuals_position_levels[,"level"] <- factor(
               x = df_residuals_position_levels[,"level"],       # La variable original de factor
          levels = df_residuals_position_levels[,"level"]  # El orden de los niveles que calculamos en el Paso 2
  )
    
  rownames(df_residuals_position_levels) <- NULL

  df_residuals_position_levels
```
  
  
# Medidas de dispersión de los residuos para cada nivel del factor.
```{r eval=TRUE, echo=TRUE}   

  # # # Partitioned Measures of Dispersion (residuals)
  df_residual_dispersion_levels <- data.frame(
    "order_level"  = 1:nlevels(my_minidataset_ext[,var_name_factor]),
    "level" = levels(my_minidataset_ext[,var_name_factor]),
    "n"            = tapply(my_minidataset_ext[,"residuals"], my_minidataset_ext[,var_name_factor], length),
    "variable"     = rep("residuals", nlevels(my_minidataset[,var_name_factor])),
    "range"        = NA,
    "variance"     = tapply(my_minidataset_ext[,"residuals"], my_minidataset_ext[,var_name_factor], var),
    "standard_deviation" = tapply(my_minidataset_ext[,"residuals"], my_minidataset_ext[,var_name_factor], sd),
    "standard_error" = NA,
    "IQR" = NA,
    "vc" = NA,
    "pvc" = NA,
    stringsAsFactors = FALSE
  )
  df_residual_dispersion_levels$"range" <- df_residuals_position_levels$"max" - df_residuals_position_levels$"min"
  df_residual_dispersion_levels$"standard_error" <- df_residual_dispersion_levels$"standard_deviation"/sqrt(df_residual_dispersion_levels$"n")
  df_residual_dispersion_levels$"IQR" <- df_residuals_position_levels$"Q3" - df_residuals_position_levels$"Q1"
  df_residual_dispersion_levels$"cv"  <- df_residual_dispersion_levels$"standard_deviation" / df_residuals_position_levels$"mean"
  df_residual_dispersion_levels$"pcv" <- paste0(df_residual_dispersion_levels$"cv"*100, "%")
  #   
  df_residual_dispersion_levels[,"level"] <- factor(
        x = df_residual_dispersion_levels[,"level"],       # La variable original de factor
        levels = df_residual_dispersion_levels[,"level"]  # El orden de los niveles que calculamos en el Paso 2
  )
  rownames(df_residual_dispersion_levels) <- NULL
  df_residual_dispersion_levels
```  
  
  
# Medidas de posicion general de los residuos (sin grupos).
```{r eval=TRUE, echo=TRUE}    
  # # # General Measures of Position (residuals)
  df_residuals_position_general <- data.frame(
    "variable"  = "residuals",
    "n"         = length(my_minidataset_ext$"residuals"),
    "min" = min(my_minidataset_ext$"residuals"),
    "mean" = mean(my_minidataset_ext$"residuals"),
    "Q1"        = quantile(my_minidataset_ext$"residuals", 0.25),
    "median" = median(my_minidataset_ext$"residuals"),
    "Q3"        = quantile(my_minidataset_ext$"residuals", 0.75),
    "max" = max(my_minidataset_ext$"residuals"),
    stringsAsFactors = FALSE
  )
  df_residuals_position_general
```
  

# Medidas de dispersion general de los residuos (sin grupos).
```{r eval=TRUE, echo=TRUE}   
  # # # General Measures of Dispersion (residuals)
  df_residuals_dispersion_general <- data.frame(
    "variable"           = var_name_rv, 
    "n"                  = length(my_minidataset[,var_name_rv]),
    "range"              = NA,
    "variance"           = var(my_minidataset[,var_name_rv]),
    "standard_deviation" = sd(my_minidataset[,var_name_rv]),
    "standard_error"    = NA,
    "IQR"               = NA,
    "cv"                = NA,
    "pcv"               = NA,
    stringsAsFactors = FALSE
  )

  df_residuals_dispersion_general$"range" <- df_residuals_position_general$"max" - df_residuals_position_general$"min"
  df_residuals_dispersion_general$"standard_error" <- df_residuals_dispersion_general$"standard_deviation"/sqrt(df_residuals_dispersion_general$"n")
  df_residuals_dispersion_general$"IQR" <- df_residuals_position_general$"Q3" - df_residuals_position_general$"Q1"
  df_residuals_dispersion_general$"cv"  <- df_residuals_dispersion_general$"standard_deviation" / df_residuals_position_general$"mean"
  df_residuals_dispersion_general$"pcv" <- paste0(df_residuals_dispersion_general$"cv"*100, "%")

  rownames(df_residuals_dispersion_general) <- NULL
  
  df_residuals_dispersion_general
  
```  
  
  
  
# Tabla del plot01
```{r eval=TRUE, echo=TRUE}    

  
  
  # # # Table for plot006
  df_table_residuals_plot001 <- data.frame(
    "order" = 1:nlevels(my_minidataset_ext[,var_name_factor]),
    "level" = levels(my_minidataset_ext[,var_name_factor]),
    "n" = tapply(my_minidataset_ext$"residuals", my_minidataset_ext[,var_name_factor], length),
    "min" = tapply(my_minidataset_ext$"residuals", my_minidataset_ext[,var_name_factor], min),
    "mean" = tapply(my_minidataset_ext$"residuals", my_minidataset_ext[,var_name_factor], mean),
    "max" = tapply(my_minidataset_ext$"residuals", my_minidataset_ext[,var_name_factor], max),
    "var" = tapply(my_minidataset_ext$"residuals", my_minidataset_ext[,var_name_factor], var),
    "sd" = tapply(my_minidataset_ext$"residuals", my_minidataset_ext[,var_name_factor], sd),
    "color" = df_factor_info$color
  )
  df_table_residuals_plot001[,"level"] <- factor(
  x = df_table_residuals_plot001[,"level"],       # La variable original de factor
  levels = df_table_residuals_plot001[,"level"]  # El orden de los niveles que calculamos en el Paso 2
)
  df_table_residuals_plot001
  
  # # # Table for plot006
  df_table_residuals_plot002 <- df_table_residuals_plot001
  
  # # # Table for plot006
  df_table_residuals_plot003 <- df_table_residuals_plot001
  
  # # # Table for plot006
  df_table_residuals_plot004 <- data.frame(
    "variable" = "residuals",
    "n" = length(my_minidataset_ext$"residuals"),
    "min" = min(my_minidataset_ext$"residuals"),
    "mean" = mean(my_minidataset_ext$"residuals"),
    "max" = max(my_minidataset_ext$"residuals"),
    "var" = var(my_minidataset_ext$"residuals"),
    "sd" = sd(my_minidataset_ext$"residuals"),
    "model_error_var_MSE" = model_error_var_MSE,
    "model_error_sd" = model_error_sd
  )
  
  phrase_coment_errors <- "Model Error (MSE) "
  
  # # # Table for plot006
  df_table_residuals_plot005  <- df_table_residuals_plot004
  
  # # # Table for plot006
  df_table_residuals_plot006 <- data.frame(
    "order" = 1:nlevels(my_minidataset_ext[,var_name_factor]),
    "level" = levels(my_minidataset_ext[,var_name_factor]),
    "n" = tapply(my_minidataset_ext$studres, my_minidataset_ext[,var_name_factor], length),
    "min" = tapply(my_minidataset_ext$studres, my_minidataset_ext[,var_name_factor], min),
    "mean" = tapply(my_minidataset_ext$studres, my_minidataset_ext[,var_name_factor], mean),
    "max" = tapply(my_minidataset_ext$studres, my_minidataset_ext[,var_name_factor], max),
    "var" = tapply(my_minidataset_ext$studres, my_minidataset_ext[,var_name_factor], var),
    "sd" = tapply(my_minidataset_ext$studres, my_minidataset_ext[,var_name_factor], sd),
    "color" = df_factor_info$color
  )
   df_table_residuals_plot006[,"level"] <- factor(
  x = df_table_residuals_plot006[,"level"],       # La variable original de factor
  levels = df_table_residuals_plot006[,"level"]  # El orden de los niveles que calculamos en el Paso 2
)
  
  # # # Table for plot006
  df_table_residuals_plot007 <- df_table_residuals_plot006
  
  
  df_table_residuals_plot008 <- data.frame(
    "variable" = "studres",
    "n" = length(my_minidataset_ext$studres),
    "min" = min(my_minidataset_ext$studres),
    "mean" = mean(my_minidataset_ext$studres),
    "max" = max(my_minidataset_ext$studres),
    "var" = var(my_minidataset_ext$studres),
    "sd" = sd(my_minidataset_ext$studres)
  )
  
  
  df_table_residuals_plot009 <- df_table_residuals_plot008
  
  df_table_residuals_plot010 <- df_table_residuals_plot008
  
  #############################################################
```  
  
  
  
# Residuals - Plot001
```{r eval=TRUE, echo=TRUE}    
  
  ####### DESDE ACAAAAAAAAAAAAAAAAAAAA
  # # # Create a new plot...
  plot_residuals001 <- plotly::plot_ly()
  
  # # # Plot001 - Scatter plot for VR and FACTOR on my_minidataset_ext *****************
  plot_residuals001 <- plotly::add_trace(p = plot_residuals001,
                                         type = "scatter",
                                         mode = "markers",
                                         x = my_minidataset_ext$FACTOR,
                                         y = my_minidataset_ext$"residuals",
                                         color = my_minidataset_ext$FACTOR,
                                         colors = df_factor_info$color,
                                         marker = list(size = 15, opacity = 0.7))
  
  # # # Title and settings...
  plot_residuals001 <-   plotly::layout(p = plot_residuals001,
                                        title = "Plot 001 - Scatterplot - Residuals",
                                        font = list(size = 20),
                                        margin = list(t = 100))
  
  
  # # # Without zerolines
  plot_residuals001 <-   plotly::layout(p = plot_residuals001,
                                        xaxis = list(zeroline = FALSE),
                                        yaxis = list(zeroline = TRUE))
  
  
  plot_residuals001 <- plotly::plotly_build(plot_residuals001)
  
  # # # Plot output
  plot_residuals001
  
  
  
```  
  


# Residuals - Plot002
```{r eval=TRUE, echo=TRUE}    
  
  #library(plotly)
  plot_residuals002 <- plotly::plot_ly()
  
  # Add traces
  plot_residuals002 <- plotly::add_trace(p = plot_residuals002,
                                         type = "violin",
                                         y = my_minidataset_ext$"residuals",
                                         x = my_minidataset_ext$FACTOR,
                                         showlegend = TRUE,
                                         side = "positive",
                                         points = "all",
                                         name = "Violinplot",
                                         color = my_minidataset_ext$FACTOR,
                                         colors = df_table_residuals_plot002$color)
  
  
  
  # # # Title and settings...
  plot_residuals002 <- plotly::layout(p = plot_residuals002,
                                      title = "Plot 002 - Residuals - Scatterplot + Jitter +  Smoothed",
                                      font = list(size = 20),
                                      margin = list(t = 100))
  
  
  # # # Without zerolines...
  plot_residuals002 <- plotly::layout(p = plot_residuals002,
                                      xaxis = list(zeroline = FALSE),
                                      yaxis = list(zeroline = FALSE))
  
  plot_residuals002 <- plotly::plotly_build(plot_residuals002)
  
  # # # Output plot003_anova...
  plot_residuals002
  
  
```  
  
 
  
  
# Residuals - Plot003
```{r eval=TRUE, echo=TRUE}    
  
  
  
  plot_residuals003 <- plotly::plot_ly()
  
  # Add traces
  plot_residuals003 <- plotly::add_trace(p = plot_residuals003,
                                         type = "violin",
                                         x = my_minidataset_ext$"residuals",
                                         showlegend = TRUE,
                                         side = "positive",
                                         points = FALSE,
                                         #name = levels(my_minidataset_ext$FACTOR)[my_minidataset_ext$lvl_order_number],
                                         color = my_minidataset_ext$FACTOR,
                                         colors = df_table_residuals_plot003$color)
  
  
  
  # # # Title and settings...
  plot_residuals003 <- plotly::layout(p = plot_residuals003,
                                      title = "Plot 003 - Residuals - Scatterplot + Jitter +  Smoothed",
                                      font = list(size = 20),
                                      margin = list(t = 100))
  
  
  # # # Without zerolines...
  plot003residuals <- plotly::layout(p = plot_residuals003,
                                     xaxis = list(zeroline = FALSE),
                                     yaxis = list(zeroline = FALSE))
 
  plot_residuals003 <- plotly::plotly_build(plot_residuals003)
  
  # # # Output plot003_anova...
  plot_residuals003
  
```  
  

  
# Residuals - Plot004
```{r eval=TRUE, echo=TRUE}    
  
  
  
  plot_residuals004 <- plotly::plot_ly()
  
  # Add traces
  plot_residuals004 <- plotly::add_trace(p = plot_residuals004,
                                         type = "violin",
                                         x = my_minidataset_ext$"residuals",
                                         #x = my_minidataset_ext$FACTOR,
                                         showlegend = TRUE,
                                         side = "positive",
                                         points = "all",
                                         name = " ")#
  #color = my_minidataset_ext$FACTOR,
  #colors = df_table_factor_plot006$color)
  
  
  
  # # # Title and settings...
  plot_residuals004 <- plotly::layout(p = plot_residuals004,
                                      title = "Plot 004 - Residuals",
                                      font = list(size = 20),
                                      margin = list(t = 100))
  
  
  # # # Without zerolines...
  plot_residuals004 <- plotly::layout(p = plot_residuals004,
                                      xaxis = list(zeroline = TRUE),
                                      yaxis = list(zeroline = FALSE))
  
  plot_residuals004 <- plotly::plotly_build(plot_residuals004)
  
  # # # Output plot003_anova...
  plot_residuals004
  
  
```  
  


  
# Residuals - Plot005

```{r eval=TRUE, echo=TRUE}    
  
  # - el 5
  qq_info <- EnvStats::qqPlot(x = my_minidataset_ext$"residuals", plot.it = F,
                              param.list = list(mean = mean(my_minidataset_ext$"residuals"),
                                                sd = sd(my_minidataset_ext$"residuals")))
  
  cuantiles_teoricos <- qq_info$x
  cuantiles_observados <- qq_info$y
  
  #library(plotly)
  plot_residuals005 <- plotly::plot_ly()
  
  # Crear el gráfico QQ plot
  plot_residuals005 <- plotly::add_trace(p = plot_residuals005,
                                x = cuantiles_teoricos,
                                y = cuantiles_observados,
                                type = 'scatter', mode = 'markers',
                                marker = list(color = 'blue'),
                                name = "points")
  
  # Agregar la línea de identidad
  pendiente <- 1
  intercepto <- 0
  
  # Calcular las coordenadas de los extremos de la línea de identidad
  x_extremos <- range(cuantiles_teoricos)
  y_extremos <- pendiente * x_extremos + intercepto
  
  # Agregar la recta de identidad
  plot_residuals005 <- plotly::add_trace(p = plot_residuals005,
                                 x = x_extremos,
                                 y = y_extremos,
                                 type = 'scatter',
                                 mode = 'lines',
                                 line = list(color = 'red'),
                                 name = "identity")
  
  
  # Establecer etiquetas de los ejes
  # plot_residuals007 <- layout(p = plot_residuals007,
  #                             xaxis = list(title = 'Expected quantiles'),
  #                             yaxis = list(title = 'Observed quantiles'))
  
  plot_residuals005 <- plotly::layout(p = plot_residuals005,
                                      title = "Plot 005 - QQ Plot Residuals",
                                      font = list(size = 20),
                                      margin = list(t = 100))
  
  plot_residuals005 <- plotly::plotly_build(plot_residuals005)
  
  # Mostrar el gráfico
  plot_residuals005
  # - Fin el 5
  
```  
  

  
# Residuals - Plot006
```{r eval=TRUE, echo=TRUE}    
  
  # # # Create a new plot...
  plot_residuals006 <- plotly::plot_ly()
  
  # # # Plot001 - Scatter plot for VR and FACTOR on my_minidataset_ext *****************
  plot_residuals006 <- plotly::add_trace(p = plot_residuals006,
                                         type = "scatter",
                                         mode = "markers",
                                         x = my_minidataset_ext$fitted.values,
                                         y = my_minidataset_ext$"residuals",
                                         color = my_minidataset_ext$FACTOR,
                                         colors = df_factor_info$color,
                                         marker = list(size = 15, opacity = 0.7))
  
  # # # Title and settings...
  plot_residuals006 <-   plotly::layout(p = plot_residuals006,
                                        title = "Plot 006 - Scatterplot - Residuals vs Fitted.values",
                                        font = list(size = 20),
                                        margin = list(t = 100))
  
  
  # # # Without zerolines
  plot_residuals006 <-   plotly::layout(p = plot_residuals006,
                                        xaxis = list(zeroline = FALSE),
                                        yaxis = list(zeroline = TRUE))
  
  
  plot_residuals006 <- plotly::plotly_build(plot_residuals006)
  
  # # # Plot output
  plot_residuals006
  
  
```  
  


  
# Residuals - Plot007

```{r eval=TRUE, echo=TRUE}    
  
  # # # Create a new plot...
  plot_residuals007 <- plotly::plot_ly()
  
  # # # Plot001 - Scatter plot for VR and FACTOR on my_minidataset_ext *****************
  plot_residuals007 <- plotly::add_trace(p = plot_residuals007,
                                         type = "scatter",
                                         mode = "markers",
                                         x = my_minidataset_ext$FACTOR,
                                         y = my_minidataset_ext$studres,
                                         color = my_minidataset_ext$FACTOR,
                                         colors = df_factor_info$color,
                                         marker = list(size = 15, opacity = 0.7))
  
  # # # Title and settings...
  plot_residuals007 <-   plotly::layout(p = plot_residuals007,
                                        title = "Plot 007 - Scatterplot - Studentized Residuals",
                                        font = list(size = 20),
                                        margin = list(t = 100))
  
  
  # # # Without zerolines
  plot_residuals007 <-   plotly::layout(p = plot_residuals007,
                                        xaxis = list(zeroline = FALSE),
                                        yaxis = list(zeroline = TRUE))
  
  
  plot_residuals007 <- plotly::plotly_build(plot_residuals007)
  
  # # # Plot output
  plot_residuals007
  
  
  
```  
  
  
  
# Residuals - Plot008

```{r eval=TRUE, echo=TRUE}    
  
  
  
  #library(plotly)
  plot_residuals008 <- plotly::plot_ly()
  
  # Add traces
  plot_residuals008 <- plotly::add_trace(p = plot_residuals008,
                                         type = "violin",
                                         x = my_minidataset_ext$studres,
                                         #x = my_minidataset_ext$FACTOR,
                                         showlegend = TRUE,
                                         side = "positive",
                                         points = "all",
                                         name = " ")#
  #color = my_minidataset_ext$FACTOR,
  #colors = df_table_factor_plot006$color)
  
  
  
  # # # Title and settings...
  plot_residuals008 <- plotly::layout(p = plot_residuals008,
                                      title = "Plot 008 - Studentized Residuals",
                                      font = list(size = 20),
                                      margin = list(t = 100))
  
  
  # # # Without zerolines...
  plot_residuals008 <- plotly::layout(p = plot_residuals008,
                                      xaxis = list(zeroline = TRUE),
                                      yaxis = list(zeroline = FALSE))
 
  plot_residuals008 <- plotly::plotly_build(plot_residuals008)
  
  # # # Output plot003_anova...
  plot_residuals008
  
  
```  
  

  
# Residuals - Plot009
```{r eval=TRUE, echo=TRUE}    
  
  # el 9
  
  x <- seq(-4, 4, length.out = 100)
  y <- dnorm(x, mean = 0, 1)
  #  x <- x*model_error_sd
  densidad_suavizada <- density(x, kernel = "gaussian", adjust = 0.5)
  hist_data_studres <- hist(my_minidataset_ext$studres, plot = FALSE)
  hist_data_studres$"rel_frec" <- hist_data_studres$counts/sum(hist_data_studres$counts)
  
  densidad_studres <-  density(x = my_minidataset_ext$studres, kernel = "gaussian", adjust =0.5)
  
  #library(plotly)
  plot_residuals009 <- plotly::plot_ly()
  
  
  # plot_residuals005 <- add_trace(p = plot_residuals005,
  #                                x = densidad_studres$x,
  #                                y = densidad_studres$y,
  #                                type = 'scatter',
  #                                mode = 'lines',
  #                                name = 'densidad_studres')
  
  plot_residuals009 <- plotly::add_trace(p = plot_residuals009,
                                 x = x,
                                 y = y,
                                 type = 'scatter',
                                 mode = 'lines',
                                 name = 'Normal Standard')
  
  
  
  
  
  # # Add traces
  # plot_residuals005 <- plotly::add_trace(p = plot_residuals005,
  #                                        type = "violin",
  #                                        x = my_minidataset_ext$"residuals",
  #                                        #x = my_minidataset_ext$FACTOR,
  #                                        showlegend = TRUE,
  #                                        side = "positive",
  #                                        points = FALSE,
  #                                        name = "violinplot")#
  
  plot_residuals009 <- plotly::add_trace(p = plot_residuals009,
                                         type = "bar",
                                         x = hist_data_studres$"mids",
                                         y = hist_data_studres$"density",
                                         name = "hist - studres")
  
  plot_residuals009 <- plotly::layout(p = plot_residuals009,
                                      bargap = 0)
  
  plot_residuals009 <- plotly::layout(p = plot_residuals009,
                                      title = "Plot 009 - Studres Distribution",
                                      font = list(size = 20),
                                      margin = list(t = 100))
  
  plot_residuals009 <- plotly::plotly_build(plot_residuals009)
  
  plot_residuals009
  # fin el 9
  
```  
  
  
  
# Residuals - Plot010
```{r eval=TRUE, echo=TRUE}    
  
  
  qq_info <- EnvStats::qqPlot(x = my_minidataset_ext$studres, plot.it = F,
                              param.list = list(mean = 0,
                                                sd = 1))
  
  cuantiles_teoricos <- qq_info$x
  cuantiles_observados <- qq_info$y
  
  #library(plotly)
  plot_residuals010 <- plotly::plot_ly()
  
  # Crear el gráfico QQ plot
  plot_residuals010 <- plotly::add_trace(p = plot_residuals010,
                                x = cuantiles_teoricos,
                                y = cuantiles_observados,
                                type = 'scatter', mode = 'markers',
                                marker = list(color = 'blue'),
                                name = "points")
  
  # Agregar la línea de identidad
  pendiente <- 1
  intercepto <- 0
  
  # Calcular las coordenadas de los extremos de la línea de identidad
  x_extremos <- range(cuantiles_teoricos)
  y_extremos <- pendiente * x_extremos + intercepto
  
  # Agregar la recta de identidad
  plot_residuals010 <- plotly::add_trace(p = plot_residuals010,
                                 x = x_extremos,
                                 y = y_extremos,
                                 type = 'scatter',
                                 mode = 'lines',
                                 line = list(color = 'red'),
                                 name = "identity")
  
  
  # Establecer etiquetas de los ejes
  # plot_residuals007 <- layout(p = plot_residuals007,
  #                             xaxis = list(title = 'Expected quantiles'),
  #                             yaxis = list(title = 'Observed quantiles'))
  
  plot_residuals010 <- plotly::layout(p = plot_residuals010,
                                      title = "Plot 010 - QQ Plot - studres",
                                      font = list(size = 20),
                                      margin = list(t = 100))
  
  plot_residuals010 <- plotly::plotly_build(plot_residuals010)
  
  # Mostrar el gráfico
  plot_residuals010
  
```




```{r eval=TRUE, echo=TRUE} 

vector_all_obj_end <- ls(envir = .GlobalEnv)

# Excluir los que NO quieres guardar
vector_exclusion <- vector_all_obj_init
vector_save_obj <- setdiff(vector_all_obj_end, vector_exclusion)

# Guardar todo excepto los excluidos
save(list = vector_save_obj, file = "R_obj_env_file05_anova_descriptive_residuals.RData")

```
